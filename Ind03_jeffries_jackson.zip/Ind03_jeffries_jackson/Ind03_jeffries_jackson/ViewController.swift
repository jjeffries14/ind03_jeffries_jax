//
//  ViewController.swift
//  Ind03_jeffries_jackson
//
//  Created by Jax Jeffries on 3/29/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var stateFlag: UIImageView!
    
    @IBOutlet weak var staten: UILabel!
    
    @IBOutlet weak var statePic: UIImageView!
    
    @IBOutlet weak var stateArea: UILabel!
    
    //rowNum var that is passed from tablevc to vc to indicate which data to display
    var rowNum: Int = 0
    
    //array of state area in alphabetical order
    var stateAreas:[String] = ["52,420","665384","113,990","53,179","163,695","104,094","5,543","2,489","65,758","59,425","10,932","83,569","57,914","36,420","56,273","82,278","40,408","52,378","35,380","12,406","10,554","96,714","86,936","48,432","69,707","147,040","77,348","110,572","9,349","8,723","121,590","54,555","53,819","70,698","44,826","69,899","98,379","46,054","1,545","32,020","77,116","42,144","268,596","84,897","9,616","42,775","71,298","24,230","65,496","97,813"]
    
    //state names in alphabetical order
    var stateName:[String] = ["Alabama",
                              "Alaska",
                              "Arizona",
                              "Arkansas",
                              "California",
                              "Colorado",
                              "Connecticut",
                              "Delaware",
                              "Florida",
                              "Georgia",
                              "Hawaii",
                              "Idaho",
                              "Illinois",
                              "Indiana",
                              "Iowa",
                              "Kansas",
                              "Kentucky",
                              "Louisiana",
                              "Maine",
                              "Maryland",
                              "Massachusetts",
                              "Michigan",
                              "Minnesota",
                              "Mississippi",
                              "Missouri",
                              "Montana",
                              "Nebraska",
                              "Nevada",
                              "New Hampshire",
                              "New Jersey",
                              "New Mexico",
                              "New York",
                              "North Carolina",
                              "North Dakota",
                              "Ohio",
                              "Oklahoma",
                              "Oregon",
                              "Pennsylvania",
                              "Rhode Island",
                              "South Carolina",
                              "South Dakota",
                              "Tennessee",
                              "Texas",
                              "Utah",
                              "Vermont",
                              "Virginia",
                              "Washington",
                              "West Virginia",
                              "Wisconsin",
                              "Wyoming"]
    
    //control of imageviews and labels
    override func viewDidLoad() {
        super.viewDidLoad()
        //set label to state name
        staten?.text = stateName[rowNum]
        
        //set image view to state flag
        stateFlag?.image = UIImage(named: stateName[rowNum] + "Flag")
        
        //set state area label to state area for specific state
        stateArea?.text = stateAreas[rowNum] + " sqmi"
        
        //display state outline for specific state
        statePic?.image = UIImage(named: stateName[rowNum])
    }


}

