//
//  TableViewController.swift
//  Ind03_jeffries_jackson
//
//  Created by Jax Jeffries on 3/29/23.
//

import UIKit

class TableViewController: UITableViewController {
    //array of tuples containing state name (sname) and nickname (nick) to display in table
    let states: [(String, String)] = [(sname: "Alabama", nick: "The Yellowhammer State"),(sname: "Alaska", nick: "The Last Frontier"), (sname: "Arizona", nick: "The Grand Canyon State"),(sname: "Arkansas", nick: "The Natural State"),(sname: "California", nick: "The Golden State"),(sname: "Colorado", nick: "The Centennial State"),(sname: "Connecticut", nick: "The Constitution State"),(sname: "Delaware", nick: "The First State"),(sname: "Florida", nick: "The Sunshine State"),(sname: "Georgia", nick: "The Peach State"),(sname: "Hawaii", nick: "The Aloha State"),(sname: "Idaho", nick: "The Gem State"),(sname: "Illinois", nick: "The Prairie State"),(sname: "Indiana", nick: "The Hoosier State"),(sname: "Iowa", nick: "The Hawkeye State"),(sname: "Kansas", nick: "The Sunflower State"),(sname: "Kentucky", nick: "The Bluegrass State"),(sname: "Louisiana", nick: "The Pelican State"),(sname: "Maine", nick: "The Pine Tree State"),(sname: "Maryland", nick: "The Old Line State"),(sname: "Massachusetts", nick: "The Bay State"),(sname: "Michigan", nick: "The Great Lakes State"),(sname: "Minnesota", nick: "The North Star State"),(sname: "Mississippi", nick: "The Magnolia State"),(sname: "Missouri", nick: "The Show Me State"),(sname: "Montana", nick: "The Treasure State"),(sname: "Nebraska", nick: "The Cornhusker State"),(sname: "Nevada", nick: "The Silver State"),(sname: "New Hampshire", nick: "The Granite State"),(sname: "New Jersey", nick: "The Garden State"),(sname: "New Mexico", nick: "The Land of Enchantment"),(sname: "New York", nick: "The Empire State"),(sname: "North Carolina", nick: "The Tar Heel State"),(sname: "North Dakota", nick: "The Peace Garden State"),(sname: "Ohio", nick: "The Buckeye State"),(sname: "Oklahoma", nick: "The Sooner State"),(sname: "Oregon", nick: "The Beaver State"),(sname: "Pennsylvania", nick: "The Keystone State"),(sname: "Rhode Island", nick: "The Ocean State"),(sname: "South Carolina", nick: "The Palmetto State"),(sname: "South Dakota", nick: "The Mount Rushmore State"),(sname: "Tennesee", nick: "The Volunteer State"),(sname: "Texas", nick: "The Lone Star State"),(sname: "Utah", nick: "The Beehive State"),(sname: "Vermont", nick: "The Green Mountain State"),(sname: "Virginia", nick: "The Old Dominion State"),(sname: "Washington", nick: "The Evergreen State"),(sname: "West Virginia", nick: "The Mountain State"),(sname: "Wisconsin", nick: "The Badger State"),(sname: "Wyoming", nick: "The Equality or Cowboy State")]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source
    //only one section so returns 1
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
        
    }

    //returns # of states, could be hard coded to 50 but for dynamic tables it is best to use arr.count method. also allows for easier implementation if any current terriotory becomes a new state
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return states.count //returns #  of states
        
    }

    //cell setup
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //links cells to identifier
        let cell = tableView.dequeueReusableCell(withIdentifier: "states", for: indexPath)

        //use of tuple array to list name and nickname
        let cellData: (sname: String, nick: String) = states[indexPath[1]]
        cell.textLabel?.text = cellData.sname
        cell.detailTextLabel?.text = cellData.nick
        
        
        return cell
    }
    
    //prepare method to pass info through segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = tableView.indexPathForSelectedRow
    
        //if destination is viewcontroller pass indexPath.row as row num to vc
        //if segue.destination method allows for multiple new views if desired (obviously not for this project)
        if let vc = segue.destination as? ViewController{
            vc.rowNum = indexPath?.row ?? 0
            
        }
    }
    
    //adds section title
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "States"
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
